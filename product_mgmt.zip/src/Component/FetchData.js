import axios from 'axios';
import React, { Component } from 'react'
import DeleteProduct from './DeleteProduct';

import UpdateProduct from './UpdateProduct';

export class FetchData extends Component {
constructor(props)
{
    super(props);
    this.state=
    {
        product:[],
        errorMsg:"",
    };
}
    componentDidMount()
    {
        axios
        .get("http://localhost:8085/getAll")
        .then((response) => {
            console.log(response);
            this.setState({product:response.data});
        })
        .catch((error) =>{
            console.log("Error is" + error);
            this.setState({errorMsg: "Error receiving data"});
        });
    }


  render() {
      const {product,errorMsg} = this.state;
    return (
      <div class="table">
          <h1>Product List</h1>
          <table>
              <tr>
                 <th>Product Id</th> 
                 <th>Product Name</th>
                 <th>Product Price</th>
                 </tr>
              
          {
              product.length
              ? product.map((product) => <div>
                  <tr>
                      <td>{product.id}</td>
                      <td>{product.name}</td>
                      <td>{product.price}</td>
                      <td><DeleteProduct id={product.id}/></td>
                      <td><UpdateProduct id={product.id}/></td>
                  </tr>
                  {/* <ul>
                      <li>{product.id}</li>
                      <li>{product.name}</li>
                      <li>{product.price}</li>
                      </ul> */}
                      </div>)
              : null
          }
          {errorMsg ? <div>{errorMsg}</div> : null}
          </table>
      </div>
    )
  }
}

export default FetchData