import React from 'react'
import axios from 'axios';
import props from 'react'

function DeleteProduct({id}) 
{
const handleDelete = () => {
    <h2>console.log("id="+id);</h2>


    //event.preventDefault();
    //alert(`The name you entered was: ${id} ${name} ${price}`);
    axios
    .delete("http://localhost:8085/delete/"+id
    )
    .then((response => console.log(response)))
    .catch(err=>console.log(err))
    alert(`Data deleted successfully`);
    
  
}

  return (
    <div>
    <button onClick={()=>handleDelete()}>Delete</button>
    </div> )
}

export default DeleteProduct