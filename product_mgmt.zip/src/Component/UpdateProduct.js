import axios from "axios"
import { useState } from "react"


const UpdateProduct = () => {
    const[product,setProduct]=useState({
        id:0,
        name:'',
        price:0
    })
   const submitHandler=(event)=>{
    axios.put('http://localhost:8085/update/'+product.product_id,product)
    .then(response=>{
        console.log(response)
        window.location.reload();
    })
    .catch(error=>{
        this.setState({errorMsg:"error updating data"})
    })
      event.preventDefault()
  }

  return (
    <div>
        <form className="w-50" onSubmit={submitHandler}>
            <div className="form-group">
            <label className='label'>Product Name :</label><br/>
                <input
                    type="text"
                    className="form-control"
                    id="product_id"
                    placeholder="Enter id"
                    onChange={(event)=>setProduct((prevState)=>({...prevState,productName:event.target.value}))}
                />
        {/* {errors.name && errors.} */}
        {/* <span style={{ color: "red" }}>{error.name}</span> */}
            </div>
            <div className="form-group">
            <label className='label'>Product Price :</label><br/>
                <input
                    type="text"
                    className="form-control"
                    placeholder="Enter Product Name"
                    onChange={(event)=>setProduct((prevState)=>({...prevState,price:event.target.value}))}
                />
            </div>
    
            <button type="submit" className="btn btn-primary">
            Submit
            </button>
        </form>
    </div>
  )
}

export default UpdateProduct
