import { useState } from "react";
import ReactDOM from 'react-dom';

function Form() {
  const [name, setName] = useState("");
  const [pwd, setPwd] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    alert(`The name you entered was: ${name} and password is : ${pwd}`)
  }

  return (
    <form onSubmit={handleSubmit}>
      <label>Enter your name:
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </label>

      <label>Enter your password:
        <input 
          type="text" 
          value={pwd}
          onChange={(e) => setPwd(e.target.value)}
        />
      </label>
      <input type="submit" />
    </form>
  )
}

export default Form