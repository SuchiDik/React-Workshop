import React from 'react'

function Home() {
  return (
    <div>
        <h1>Welcome to Product Management System</h1>
    </div>
  )
}

export default Home