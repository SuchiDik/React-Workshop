import logo from './logo.svg';
import './App.css';
//import Product from './Component/Product';
//import Form from './Component/Form';
//import AddProduct from './Component/AddProduct';
import FetchData from './Component/FetchData';
import DeleteProduct from './Component/DeleteProduct';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom'
import UpdateProduct from './Component/UpdateProduct';
function App() {
  return (
    <div className="App">
    <BrowserRouter>
    <nav>
          <Link to="/delete">Delete</Link><br/>
          <Link to="/all">All</Link>
          <Link to="/update">Edit</Link>
      </nav>
      <Routes>

           <Route path="/delete" element={<DeleteProduct/>}></Route>
           <Route path="/all" element={<FetchData/>}></Route>
           <Route path="/update" element={<UpdateProduct/>}></Route>
      </Routes>
    </BrowserRouter>
     

     
    </div>
  );
}

export default App;
