import React, { Component } from 'react'

export class Header extends Component {
  render() {
    return (
      <div className='header'>Welcome To React Workshop</div>
    )
  }
}

export default Header