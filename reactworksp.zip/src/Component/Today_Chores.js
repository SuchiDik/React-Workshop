import React, { Component } from 'react'
import './header.css'
export class Today_Chores extends Component {
  render() {
    return (
      <div className='today_chores'><h1>Today_Chores</h1>
<ul>

      <li>Empty Dishwasher</li>
      <li>Complete LaunchCode Prep work</li>
      <li>Buy Groceries</li>

</ul>


      </div>
    )
  }
}

export default Today_Chores