import React, { Component } from 'react'

export class Fav_Movie extends Component {
  render() {
    
    return (
      <div className='fav_mov'><h1>Fav_Movie</h1>

<ul>
    <li>Wonder Woman</li>
    <li>Jagga Jasoos</li>
    <li>RRR</li>
    <li>Popcorn</li>

</ul>




      </div>
    )
  }
}

export default Fav_Movie