import React, { Component } from 'react'
import './header.css'
export class Footer extends Component {
  render() {
    return (
      <div className='footer'>Copyright Reserved</div>
    )
  }
}

export default Footer