import React from 'react'
import PropTypes from 'prop-types'
import ListOfWatched from './ListOfWatched';
import {Card,ListGroup,ListGroupItem,Link} from 'react-bootstrap'
function Fav_Movies(props) {
 const Watched=["Pavankhind","WW","RRR"];
   const UnWatched=["Paa","Vampire Diaries","Baaghi"];
    const{name, flag}=props;
    if(flag=="true")
  return (
      <div className='watched'>
  <h1>Watched Movies</h1>
  <ol>
      {Watched.map((watched) => (
        <h2><li>{watched}</li></h2>
      ))}
    
  <h1>Watch to be</h1>
      {UnWatched.map((unwatched) => (
        <h2><li>{unwatched}</li></h2>
      ))}
    </ol>
        </div>
  )
  else{
    return (
      <div className='unwatched'>
  <h1>UnWatched Movies</h1>
  <ol>
      {UnWatched.map((unwatched) => (
        <li>{unwatched}</li>
      ))}
    </ol>
        </div>
  )

  }
}
Fav_Movies.propTypes={
    name:PropTypes.string.isRequired,
    flag:PropTypes.string.isRequired

}

export default Fav_Movies