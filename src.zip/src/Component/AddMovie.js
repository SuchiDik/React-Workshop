import React from 'react';
import { useState } from "react";
import { Row } from "react-bootstrap";
import ReactDOM from 'react-dom';
import { Col } from "react-bootstrap";
import {useEffect} from 'react';


const AddMovie = () => {
const list=["Paa","Gajni"];
    //const [comment, setComment] = useState("");
    const [lists, setLists] = React.useState(list);
    const [Moviename, setMovieName] = useState("");
    //const [Rating, setRating] = useState("")


    const handleChange = event => {
        //setComment({[event.target.name]: event.target.value})
        //setRating({[event.target.name]: event.target.value})
        setMovieName(event.target.value);
        alert(event.target.value);
       
    }

    const handleClick = event => {  
        list.push(Moviename);
   
        setLists(list);

    }   
console.log(lists);
    return (
        <main>
           
            <div className="form">
            <input type="text" placeholder="Enter moviename" name="Moviename" onChange={handleChange} ></input>
           <button onClick={handleClick}>Add</button>
            </div>
            <ul>
        {lists.map((item) => (
          <li>{item}</li>
        ))}
      </ul>
            
    
                  </main>
    )
}

export default AddMovie;
// function AddMovie() {
//     const initialList = [];
// // const [Id, setId] = useState("");
//   const[MovieName,setMovieName] = useState("");
// //  const[Rating,setRating]= useState("");
//    const [newinitialList, setnewinitialList] = useState("");

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     alert(`Movie Detalis entered was: ${Id} ${MovieName} ${Rating}`);
//   }

//   const handleAdd=(e)=>
//   {

//  const newinitialList=[...initialList];
//  newinitialList.push({MovieName});
// //  newinitialList.push({Id});
// //  newinitialList.push({Rating});
//  setnewinitialList(newinitialList);
//   }

//   return (
//       <div class="myForm">
//        <h1>Add Movie</h1>
//     <form onSubmit={handleSubmit}>
//      <Row>
//      <Col xs={1} sm={1} className="list"></Col>
//            <label>Enter Id:
//         <input 
//           type="text" 
//           value={Id}
//           onChange={(e) => setId(e.target.value)}
//         />
//       </label>
//       </Row>
//            <Row>
//      <Col xs={1} sm={1} className="list"></Col>
//          <label>Enter MovieName:
//         <input 
//           type="text" 
//           value={MovieName}
//           onChange={(e) => setMovieName(e.target.value)}
//         />
//       </label>
//       </Row>
//          <Row>
//      <Col xs={1} sm={1} className="list"></Col>
//           <label>Enter Rating:
//         <input 
//           type="text" 
//           value={Rating}
//           onChange={(e) => setRating(e.target.value)}
//         />
//       </label>
//       </Row> 
//          <Row>
//      <Col xs={1} sm={1} className="list"></Col>
//          <input type="submit" onClick={handleAdd}/>
//          </Row>
//     </form>

//     <ul>
//         {initialList.map((item) => (
//             <>
//           <li>{item.Moviename}</li>
//           {/* <li>{item.id}</li>
//           <li>{item.Rating}</li> */}
//           </>
//         ))}
//       </ul>

//     </div>
//   )
// }

// export default AddMovie
