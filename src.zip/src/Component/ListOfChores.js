import React, { Component } from 'react'
import {Row,Col,Card,ListGroup,ListGroupItem} from 'react-bootstrap'
import './header.css'
import Chores from './Chores';
export class ListOfChores extends Component {
  render() {
    return (
      <div>

<Card style={{ width: '18rem' }}>

            <Row >
                <Col xs={1} sm={1} className="images">
              <Card.Body>    
              <Card.Title>List Of Chores</Card.Title> </Card.Body>  
              <ListGroup className="list-group-flush">
    <ListGroupItem><p>{this.props.chore}</p></ListGroupItem>  
    <ListGroupItem><p>{this.props.display}</p></ListGroupItem>
                  </ListGroup>
                </Col>

            </Row>
      </Card>
            </div>
        );
   
  }
}

export default ListOfChores;