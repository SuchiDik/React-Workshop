import React, { Component } from 'react'

import ListOfChores  from './ListOfChores';

export class Chores extends Component {
  render() {
    
 

     const Today_Chores = [{
        chore:"PayLightbill"
     },
     {
          chore:"Buy Groceries"
      },
    {
       
        chore:"Empty Dishwasher"
    }
]

 const Yesterday_Chores = [{
  chore:"Wash clothes"
  },
  {
  chore:"Wash Car"
 },
{
 
  chore:"Empty Dishwasher"
}
,
{
 
  chore:"Wash Hairs"
}
]
const Tomorrow_Chores = [{
  chore:"Wash clothes"
},
{
  chore:"cut the trees"
},
{
 
  chore:"Decorate Garden"
}
,
{
 
  chore:"Clean bathroom"
}
]

const total_length=Today_Chores.length+Yesterday_Chores.length;
if(total_length < Tomorrow_Chores.length)
    return (
      <div className='random_image'>
        <h1>Yesterday_Chores</h1>
           {Yesterday_Chores.map((e,i) =>
                    <ListOfChores
                    chore={e.chore}
                     key={i}
                    />
                )}

<h1>Today_Chores</h1>
           {Today_Chores.map((e,i) =>
                    <ListOfChores
                    chore={e.chore}
                     key={i}
                    />
                )}
   <h1>Tomorrow_Chores</h1>
           {Tomorrow_Chores.map((e,i) =>
                    <ListOfChores
                    chore={e.chore}
                     key={i}
                    />
                )}

          
          <h1>Work harder</h1>
      </div>
      
    )
else{
    return (
      <div className='random_image'>
        <h1>Yesterday_Chores</h1>
           {Yesterday_Chores.map((e,i) =>
                    <ListOfChores
                    chore={e.chore}
                     key={i}
                    />
                )}

<h1>Today_Chores</h1>
           {Today_Chores.map((e,i) =>
                    <ListOfChores
                    chore={e.chore}
                     key={i}
                    />
                )}
   <h1>Tomorrow_Chores</h1>
           {Tomorrow_Chores.map((e,i) =>
                    <ListOfChores
                    chore={e.chore}
                     key={i}
                    />
                )}

          
  <h1>Hurray,Ice cream Treat....</h1>
      </div>

    )
           }
  }
}

export default Chores