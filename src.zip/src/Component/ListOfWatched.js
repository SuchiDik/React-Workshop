import React, { Component } from 'react'
import {Row,Col} from 'react-bootstrap'
import './header.css'
import Chores from './Chores';
export class ListOfWatched extends Component {
  render() {
    return (
      <div>

      
            <Row >
                <Col xs={1} sm={1} className="images">
                   
                    <p>{this.props.name}</p>
                 
                </Col>

            </Row>
            
            </div>
        );
   
  }
}

export default ListOfWatched;