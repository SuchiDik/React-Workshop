import React, { Component } from 'react'

export class Fav_ClassComp extends Component {

    constructor(props)
    {
        super(props)
        this.state={name:'RRR',image:'https://jpeg.org/images/jpeg-home.jpg'}
        console.log("constructor")
    }

changeState=()=>{

    this.setState(
        
        {name:"Wonder woman",image:'https://upload.wikimedia.org/wikipedia/commons/3/3f/JPEG_example_flower.jpg',
        name: "Pavankhind" ,image:"https://www.imgonline.com.ua/examples/jpeg-artifacts_3x.png"});
}

// componentDidMount() {
//     setTimeout(() => {
//       this.setState({name: "Pavankhind" ,image:"https://www.imgonline.com.ua/examples/jpeg-artifacts_3x.png" })
//     }, 3000)
//   }


  render() {
    return (
      <div>
          
          
        Movie Name={this.state.name} <br/><br/>
        <img src={this.state.image} alt="image"/><br/>


      <button
      type="button"
      onClick={this.changeState}>ChangeImage</button>
</div>
    )
  }
}

export default Fav_ClassComp