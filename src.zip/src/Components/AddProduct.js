import axios from 'axios';
import { useState } from "react";
import ReactDOM from 'react-dom';
import '../CSS/AddProduct.css'

function AddProduct() {
  const [id, setId] = useState("");
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    //alert(`The name you entered was: ${id} ${name} ${price}`);
    axios
    .post("http://localhost:8085/addProduct",
    {
        id:id,
        name:name,
        price:price
    })
    .then((response => console.log(response)))
    .catch(err=>console.log(err))
    alert(`Data added successfully`);
  }



  return (
    <div class="add">
      <h1>Add Product</h1>
    <form onSubmit={handleSubmit}>
      <label>Enter Id:
        <input 
          type="text" 
          value={id}
          onChange={(e) => setId(e.target.value)}
        />
      </label>
      <label>Enter Product Name:
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </label>
      <label>Enter Product Price:
        <input 
          type="text" 
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
      </label>
      <input type="submit" />
    </form>
    </div>
  )
}

export default AddProduct
