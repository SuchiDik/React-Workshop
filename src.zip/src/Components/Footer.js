import React from 'react'
import '../CSS/Footer.css'

function Footer() {
  return (
    <div class="footer">
        <p>Footer</p>
      </div>
  )
}

export default Footer