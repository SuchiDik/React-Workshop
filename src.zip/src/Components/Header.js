import React from 'react'
import { Link,li,ul } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'
function Header() {
  return (
    <div>  
    <ul
    class="nav justify-content-center"
    style={{backgroundColor:'Sienna',height:"5rem",
    alignItems:"center"}}>

    <li class="nav-item">
    <Link to="/" className="nav-link" aria-current="page">Home</Link></li>        

    {/* <li class="nav-item">
    <Link to="/displayProducts" className="nav-link">Display Products</Link></li> */}

    <li class="nav-item">
    <Link to="/addProducts" className="nav-link">Add Products</Link> </li>
    
    {/* <li class="nav-item">
    <Link to="/login" className="nav-link">Login</Link></li>

    <li class="nav-item">
    <Link to="/register" className="nav-link">Register</Link></li> */}

    {/* <li class="nav-item">
        <Link to="/formvalidation" className="nav-link">From Validation</Link></li>

    <li class="nav-item">
    <Link to="/formsv" className="nav-link">Form</Link> </li> */}

    <li class="nav-item">
    <Link to="/fetch" className="nav-link">Fetch Data</Link></li>

    </ul>

  </div>

        
  )
}

export default Header