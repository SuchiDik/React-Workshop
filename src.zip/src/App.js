import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Route,Routes} from 'react-router-dom'
import { FetchData } from './Components/FetchData';
import AddProduct from './Components/AddProduct';
import Header from './Components/Header';
import Error from './Components/Error';
import Footer from './Components/Footer';
import Home from './Components/Home';

function App() {
  return (
    <div className="App">
      {/* <FetchData/> */}
      {/* <AddProduct/> */}
      <BrowserRouter>
        <Header></Header>
        <Routes>
          <Route path='/' element={<Home></Home>}></Route>
          {/* <Route path='/home' element={<Home></Home>}></Route> */}
          {/* <Route path='/displayProducts' element={<DisplayProduct></DisplayProduct>}></Route> */}
          <Route path='/addProducts' element={<AddProduct/>}></Route>
          {/* <Route path='/login' element={<Login></Login>}></Route>
          <Route path='/register' element={<Register></Register>}></Route>
          <Route path='/formvalidation' element={<FormValidation></FormValidation>}></Route>
          <Route path='/practice' element={<PracticeFile></PracticeFile>}></Route>
          <Route path='/formsv' element={<Form></Form>}></Route> */}
          <Route path='/fetch' element={<FetchData/>}></Route>
          <Route path='*' element={<Error></Error>}></Route>
        </Routes>
        <Footer></Footer>
        </BrowserRouter>
    </div>
  );
}

export default App;
