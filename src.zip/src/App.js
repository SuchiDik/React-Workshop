import logo from './logo.svg';
import './App.css';
import Header from './Component/Header';
import Footer from './Component/Footer';
import { BrowserRouter, Routes, Route,Link} from "react-router-dom"
import AddMovie from './Component/AddMovie';
import Fav_Movies from './Component/Fav_Movies';
import Chores from './Component/Chores';
import Navigation from './Component/Navigation';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navigation></Navigation>
    <Routes>
        <Route path="#add" element={<AddMovie/>}></Route>
        <Route path="#chores" element={<Chores/>}></Route>
        <Route path="/fav" element={<Fav_Movies name="Baggi" flag="true"/>}></Route>
    </Routes>

    </BrowserRouter>
    
    </div>
  );
}

export default App;
